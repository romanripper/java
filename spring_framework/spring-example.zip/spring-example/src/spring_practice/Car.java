package spring_practice;

public interface Car {
	String getEngineSound();
}
