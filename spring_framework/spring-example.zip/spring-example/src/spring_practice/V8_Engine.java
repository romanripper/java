package spring_practice;

public class V8_Engine implements Engine{
	
	@Override
	public String getSound() {
		return "Vroom Vroom";
	}
}
