package spring_practice;

public interface Engine {
	String getSound(); 
}
