package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Employee;

public class UpdateEmployeeExample {
	public static void main(String[] args) {
		try (SessionFactory factory = new Configuration()
				.configure()
				.addAnnotatedClass(Employee.class)
				.buildSessionFactory()
			) {

			Session session = factory.getCurrentSession();

			session = factory.getCurrentSession();

			session.beginTransaction();
			
			System.out.println("\nUpdating employee...");
			session.createQuery(
					"update Employee "
				  + "set firstName = 'Sadio', lastName = 'Mane' " 
				  + "where company = 'Liverpool'").executeUpdate();

			session.getTransaction().commit();

		}

	}
}
