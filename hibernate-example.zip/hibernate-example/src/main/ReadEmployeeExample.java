package main;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Employee;

public class ReadEmployeeExample {
	public static void main(String[] args) {
		try (SessionFactory factory = new Configuration()
				.configure()
				.addAnnotatedClass(Employee.class)
				.buildSessionFactory()) {

			Session session = factory.getCurrentSession();

			int employeeId = 2;
			
			session = factory.getCurrentSession();
			session.beginTransaction();
			
			System.out.println("\nRetrieving employee with id = " + employeeId + "...");
			Employee employee = session.get(Employee.class, employeeId);
			
			if(employee == null) {
				System.out.println("Sorry, no employee with id = " + employeeId);
			}
			else {
				System.out.println("Retrieved employee: " + employee);
			}
			
			session.getTransaction().commit();

		}

	}
}
