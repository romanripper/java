package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Employee;

public class CreateEmployeeExample {

	public static void main(String[] args) {
		try (SessionFactory factory = new Configuration()
				.configure()
				.addAnnotatedClass(Employee.class)
				.buildSessionFactory()
			) {
			
			Session session = factory.getCurrentSession();
			
			session.beginTransaction();
			
			Employee emp1 = new Employee("Axel", "Witsel", "Borussia Dortmund");
			Employee emp2 = new Employee("Alexandr", "Zinchenko", "Manchester City");
			Employee emp3 = new Employee("Mo", "Salah", "Liverpool");		
			
			System.out.println("\nCreating employees...");
			session.save(emp1);
			session.save(emp2);
			session.save(emp3);
			
			session.getTransaction().commit();	
		
		}

	}

}
