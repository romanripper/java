package main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Employee;

public class DeleteEmployeeExample {
	public static void main(String[] args) {
		try (SessionFactory factory = new Configuration()
				.configure()
				.addAnnotatedClass(Employee.class)
				.buildSessionFactory()
			) {

			Session session = factory.getCurrentSession();

			int employeeId = 7;
			
			session = factory.getCurrentSession();
			session.beginTransaction();
			
//			System.out.println("\nDeleting employee with id = " + employeeId + "...");
//			session.createQuery(
//					"delete Employee "
//				  + "where firstName = " + employeeId).executeUpdate();
			
			Employee employee = session.get(Employee.class, employeeId);	
			if(employee == null) {
				System.out.println("Sorry, no employee with id = " + employeeId);
			}
			else {
				System.out.println("\nDeleting employee: " + employee);
				session.delete(employee);
			}
			
			session.getTransaction().commit();

		}

	}
}
